<?php

//connect server data

$servername = "localhost";
$username = "user";
$password = "";

$link = mysqli_connect("localhost", "user", "", "per_board") or die("connect error!");
